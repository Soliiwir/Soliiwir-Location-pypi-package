from .navigationLocBook import *  # imports all functions/classes
from .main import *  # if you want functions in main.py available

__all__ = ["navigationLocBook", "main"]
